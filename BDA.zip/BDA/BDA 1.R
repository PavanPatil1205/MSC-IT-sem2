# Load required libraries
require(foreign)
require(MASS)

# Import dataset from web storage
# This is a CSV file containing admit, gre, gpa, and rank
admission_data <- read.csv("https://stats.idre.ucla.edu/stat/data/binary.csv")

# View the first few rows
head(admission_data)

# Convert rank to a factor
admission_data$rank <- factor(admission_data$rank)

# Summary of data to check for missing values
summary(admission_data)

# Build the Logit model
# admit ~ . means predict admit using all other columns
logit_model <- glm(admit ~ gre + gpa + rank, 
                   data = admission_data, 
                   family = "binomial")

# View the results
summary(logit_model)

# 1. Check for Overall Model Significance
# Comparing our model to a 'null' model (a model with no predictors)
with(logit_model, pchisq(null.deviance - deviance, df.null - df.residual, lower.tail = FALSE))

# 2. Confusion Matrix to check accuracy
# We predict probabilities; if > 0.5, we classify as 'Admitted'
predictions <- predict(logit_model, type = "response")
predicted_class <- ifelse(predictions > 0.5, 1, 0)

# Create a table of Actual vs Predicted
table(Actual = admission_data$admit, Predicted = predicted_class)