# Ensure libraries are loaded
library(MASS)

# Use the dataset from the previous step
# (Assuming admission_data is already loaded)
# If not: admission_data <- read.csv("https://stats.idre.ucla.edu/stat/data/binary.csv")

# Ensure rank is a factor
admission_data$rank <- factor(admission_data$rank)

# Formula: gre ~ gpa + rank
# We are seeing how GPA and Rank together influence the GRE score
multiple_reg_model <- lm(gre ~ gpa + rank, data = admission_data)

# Display the statistical results
summary(multiple_reg_model)

# Plot diagnostic graphs
# This will show 4 plots; press Enter in the console to see each one
par(mfrow = c(2, 2)) # Arrange plots in a 2x2 grid
plot(multiple_reg_model)