# Install packages (only need to do this once)
install.packages("caret")
install.packages("randomForest")

# Load the libraries
library(caret)
library(randomForest)

# Load built-in dataset
data(iris)

# Set a seed for reproducibility (so you get the same results every time)
set.seed(123)

# Create an index to split 80% for training, 20% for testing
trainIndex <- createDataPartition(iris$Species, p = 0.8, list = FALSE)
trainData <- iris[trainIndex, ]
testData  <- iris[-trainIndex, ]


# Train the model
# Species ~ . means "Predict Species using all other variables"
model <- train(Species ~ ., 
               data = trainData, 
               method = "rf", 
               trControl = trainControl(method = "cv", number = 5)) # 5-fold cross-validation

# View model details
print(model)

# Make predictions on the test set
predictions <- predict(model, testData)

# Evaluate using a Confusion Matrix
evaluation <- confusionMatrix(predictions, testData$Species)

# Print the results
print(evaluation)