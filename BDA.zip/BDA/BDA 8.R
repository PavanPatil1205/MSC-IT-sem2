install.packages("e1071")   # run once
library(e1071)

data(iris)
head(iris)

set.seed(123)

index <- sample(1:nrow(iris), 0.7 * nrow(iris))
train_data <- iris[index, ]
test_data  <- iris[-index, ]

svm_linear <- svm(
  Species ~ ., 
  data = train_data, 
  kernel = "linear"
)

pred_linear <- predict(svm_linear, test_data)

table(Predicted = pred_linear, Actual = test_data$Species)
mean(pred_linear == test_data$Species)

library(caret)

confusionMatrix(pred-rbf, test_data$Species)

