# Load the dataset
data(iris)

# Remove the Species column (column 5) for unsupervised learning
iris_cluster <- iris[, -5]

# Scale the data (Standardization) 
# This ensures variables with larger numbers don't dominate the model
iris_scaled <- scale(iris_cluster)

# Determine number of clusters
set.seed(123)
wss <- sapply(1:10, function(k){kmeans(iris_scaled, k, nstart=20 )$tot.withinss})

# Plot the elbow curve
plot(1:10, wss, type="b", pch = 19, frame = FALSE, 
     xlab="Number of clusters K",
     ylab="Total within-clusters sum of squares")

# Apply K-Means
set.seed(123)
km_result <- kmeans(iris_scaled, centers = 3, nstart = 25)

# View the cluster assignments
print(km_result$cluster)

# Install and load visualization package
if(!require(factoextra)) install.packages("factoextra")
library(factoextra)

# Plot the clusters
fviz_cluster(km_result, data = iris_scaled,
             palette = "jco",
             geom = "point",
             ellipse.type = "convex", 
             ggtheme = theme_minimal(),
             main = "K-Means Clustering Results")