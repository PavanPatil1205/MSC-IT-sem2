# Install relevant packages
install.packages("rpart")
install.packages("rpart.plot")

# Load the libraries
library(rpart)
library(rpart.plot)

# Load data
data(iris)

# Set seed for reproducibility
set.seed(42)

# Split data: 70% Training, 30% Testing
sample_index <- sample(1:nrow(iris), 0.7 * nrow(iris))
train_data <- iris[sample_index, ]
test_data  <- iris[-sample_index, ]

# Train the Decision Tree model
dt_model <- rpart(Species ~ ., data = train_data, method = "class")

# View a text summary of the tree
print(dt_model)

# Plot the tree
rpart.plot(dt_model, type = 4, extra = 101, under = TRUE, cex = 0.8, box.palette = "GnBu")

# Make predictions on the test set
dt_predictions <- predict(dt_model, test_data, type = "class")

# Create a Confusion Matrix
conf_matrix <- table(test_data$Species, dt_predictions)
print(conf_matrix)

# Calculate Accuracy
accuracy <- sum(diag(conf_matrix)) / sum(conf_matrix)
print(paste("Accuracy:", round(accuracy, 4)))
