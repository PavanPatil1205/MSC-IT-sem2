import numpy as np
import cv2 as cv
import sys

criteria = (cv.TERM_CRITERIA_EPS + cv.TERM_CRITERIA_MAX_ITER, 30, 0.001)

# INNER corners = 7 x 7
objp = np.zeros((7*7, 3), np.float32)
objp[:, :2] = np.mgrid[0:7, 0:7].T.reshape(-1,2)

objpoints = []
imgpoints = []

images = [r"C:\Users\pavan\Downloads\computer vision\3\Chess.jpg"]

print("Images found:", images)

for fname in images:
    img = cv.imread(fname)

    if img is None:
        continue

    gray = cv.cvtColor(img, cv.COLOR_BGR2GRAY)

    # preprocessing (important for wooden board)
    gray = cv.GaussianBlur(gray, (5,5), 0)
    gray = cv.equalizeHist(gray)
    flags = cv.CALIB_CB_ADAPTIVE_THRESH + cv.CALIB_CB_NORMALIZE_IMAGE

    ret, corners = cv.findChessboardCorners(gray, (7, 7), flags)

    if ret == True:
        objpoints.append(objp)

        corners2 = cv.cornerSubPix(gray, corners, (11, 11), (-1, -1), criteria)
        imgpoints.append(corners2)

        cv.drawChessboardCorners(img, (7, 7), corners, ret)
        cv.imshow('img', img)
        cv.waitKey(500)

cv.destroyAllWindows()

if len(objpoints) == 0:
    print("No chessboard detected. Try tilting the board and avoid reflections.")
    sys.exit()

ret, mtx, dist, rvecs, tvecs = cv.calibrateCamera(
    objpoints, imgpoints, gray.shape[::-1], None, None
)

print("Camera matrix : ")
print(mtx)
print("dist :")
print(dist)

img = cv.imread(r"C:\Users\pavan\Downloads\CV exam prp\3\Chess.jpg")
h, w = img.shape[:2]

newcameramtx, roi = cv.getOptimalNewCameraMatrix(mtx, dist, (w, h), 1, (w, h))
dst = cv.undistort(img, mtx, dist, None, newcameramtx)

x, y, w, h = roi
dst = dst[y:y+h, x:x+w]

cv.imwrite('calibresult.png', dst)

print("Done. Saved calibresult.png")
