import cv2
import numpy as np

image = cv2.imread(r'C:\Users\pavan\Downloads\computer vision\4\B\2\Line Image.jpg')
cv2.imshow('Original', image)

gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
edges = cv2.Canny(gray, 50, 150, apertureSize=3)
line_list = []
lines = cv2.HoughLinesP(
    edges,
    rho = 2,
    theta = np.pi / 180,
    threshold = 100,
    minLineLength = 20,
    maxLineGap = 5
)

for points in lines:
    x1, y1, x2, y2 = points[0]
    cv2.line(image, (x1, y1), (x2, y2), (0, 255, 0), 2)
    line_list.append([(x1, y1), (x2, y2)])

cv2.imshow('detectedlines.png', image)
cv2.waitKey(0)
cv2.destroyAllWindows()
