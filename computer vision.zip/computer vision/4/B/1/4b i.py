import cv2
from matplotlib import pyplot as plt

imaging = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\4\B\1\Stop.jpg")

if imaging is None:
    print("Image not loaded. Check path.")
    exit()

imaging_gray = cv2.cvtColor(imaging, cv2.COLOR_BGR2GRAY)
imaging_rgb = cv2.cvtColor(imaging, cv2.COLOR_BGR2RGB)

xml_data = cv2.CascadeClassifier(r"C:\Users\pavan\Downloads\computer vision\4\B\1\stop_sign_classifier_2.xml")

if xml_data.empty():
    print("XML file not loaded.")
    exit()

detecting = xml_data.detectMultiScale(imaging_gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

for (x, y, w, h) in detecting:
    cv2.rectangle(imaging_rgb, (x, y), (x + w, y + h), (0, 255, 0), 3)

plt.imshow(imaging_rgb)
plt.axis("off")
plt.title("Stop Sign Detection")
plt.show()
