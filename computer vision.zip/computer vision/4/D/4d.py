import cv2
import numpy as np

# Load face cascade
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
)

# -----------------------------
# TRAINING PART
# -----------------------------

# Load known person image
known_image = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\4\D\PAVAN.jpeg")

if known_image is None:
    print("Training image not loaded")
    exit()

gray_known = cv2.cvtColor(known_image, cv2.COLOR_BGR2GRAY)

faces = face_cascade.detectMultiScale(gray_known, 1.3, 5)

training_data = []
labels = []

for (x, y, w, h) in faces:
    face_roi = gray_known[y:y+h, x:x+w]
    face_roi = cv2.resize(face_roi, (200, 200))
    training_data.append(face_roi)
    labels.append(1)   # Label 1 = PAVAN

training_data = np.array(training_data)
labels = np.array(labels)

# Create recognizer
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.train(training_data, labels)

# -----------------------------
# RECOGNITION PART (Webcam)
# -----------------------------

cap = cv2.VideoCapture(0)

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)

    for (x, y, w, h) in faces:
        face_roi = gray[y:y+h, x:x+w]
        face_roi = cv2.resize(face_roi, (200, 200))

        label, confidence = recognizer.predict(face_roi)

        if confidence < 80:
            name = "PAVAN"
        else:
            name = "Unknown"

        cv2.rectangle(frame, (x, y), (x+w, y+h), (0,255,0), 2)
        cv2.putText(frame, name, (x, y-10),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.9, (0,0,255), 2)

    cv2.imshow("Face Recognition", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
