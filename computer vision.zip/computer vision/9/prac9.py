import cv2
import numpy as np
import matplotlib.pyplot as plt

# ===== READ YOUR IMAGE =====
img1_color = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\9\frieza.jpeg")

if img1_color is None:
    print("Image not found. Check path!")
    exit()

# ===== CREATE ROTATED IMAGE (SECOND IMAGE) =====
height, width = img1_color.shape[:2]
center = (width // 2, height // 2)

rotation_matrix = cv2.getRotationMatrix2D(center, 30, 1.0)
img2_color = cv2.warpAffine(img1_color, rotation_matrix, (width, height))

# Convert to grayscale
img1 = cv2.cvtColor(img1_color, cv2.COLOR_BGR2GRAY)
img2 = cv2.cvtColor(img2_color, cv2.COLOR_BGR2GRAY)

# ORB Feature Detector
orb = cv2.ORB_create(5000)

kp1, d1 = orb.detectAndCompute(img1, None)
kp2, d2 = orb.detectAndCompute(img2, None)

# Match features
matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
matches = matcher.match(d1, d2)

# Sort matches
matches = sorted(matches, key=lambda x: x.distance)
matches = matches[:int(len(matches) * 0.9)]

# Extract matched points
p1 = np.float32([kp1[m.queryIdx].pt for m in matches]).reshape(-1,1,2)
p2 = np.float32([kp2[m.trainIdx].pt for m in matches]).reshape(-1,1,2)

# Apply RANSAC
homography, mask = cv2.findHomography(p1, p2, cv2.RANSAC)

# Warp perspective
transformed_img = cv2.warpPerspective(img1_color, homography, (width, height))

# ===== DISPLAY OUTPUT =====
plt.figure(figsize=(10,5))

plt.subplot(1,2,1)
plt.imshow(cv2.cvtColor(img1_color, cv2.COLOR_BGR2RGB))
plt.title("Original Image")
plt.axis("off")

plt.subplot(1,2,2)
plt.imshow(cv2.cvtColor(transformed_img, cv2.COLOR_BGR2RGB))
plt.title("Transformed Image")
plt.axis("off")

plt.show()
