import cv2
import numpy as np

# ====== PATHS (CHANGE THESE) ======
img_path = (r"C:\Users\pavan\Downloads\computer vision\5\C\img.jpg")        # your image file
video_path = (r"C:\Users\pavan\Downloads\computer vision\5\C\video.mp4")     # your video file

# Read image
img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)

if img is None:
    print("❌ Image not found!")
    exit()

# Open video
cap = cv2.VideoCapture(video_path)

if not cap.isOpened():
    print("❌ Video not found!")
    exit()

# Create SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints & descriptors in image
kp_image, desc_image = sift.detectAndCompute(img, None)

# FLANN matcher
index_params = dict(algorithm=1, trees=5)  # algorithm=1 for KDTree
search_params = dict()
flann = cv2.FlannBasedMatcher(index_params, search_params)

while True:
    ret, frame = cap.read()
    if not ret:
        print("✅ Video finished")
        break

    grayframe = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    kp_frame, desc_frame = sift.detectAndCompute(grayframe, None)

    if desc_image is not None and desc_frame is not None and len(desc_image) > 0 and len(desc_frame) > 0:

        matches = flann.knnMatch(desc_image, desc_frame, k=2)
        good_points = []

        for m, n in matches:
            if m.distance < 0.75 * n.distance:
                good_points.append(m)

        if len(good_points) > 10:
            query_pts = np.float32([kp_image[m.queryIdx].pt for m in good_points]).reshape(-1, 1, 2)
            train_pts = np.float32([kp_frame[m.trainIdx].pt for m in good_points]).reshape(-1, 1, 2)

            matrix, mask = cv2.findHomography(query_pts, train_pts, cv2.RANSAC, 5.0)

            if matrix is not None:
                h, w = img.shape
                pts = np.float32([[0, 0], [0, h], [w, h], [w, 0]]).reshape(-1, 1, 2)
                dst = cv2.perspectiveTransform(pts, matrix)

                frame = cv2.polylines(frame, [np.int32(dst)], True, (0, 255, 0), 3)

        result = cv2.drawMatches(img, kp_image, frame, kp_frame, good_points, None,
                                 flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)

        cv2.imshow("SIFT Matching", result)

    else:
        cv2.imshow("Frame", frame)

    if cv2.waitKey(1) & 0xFF == 27:  # ESC key to exit
        break

cap.release()
cv2.destroyAllWindows()
