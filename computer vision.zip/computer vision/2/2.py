import cv2
import numpy as np
import matplotlib.pyplot as plt

# Load images
img1 = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\2\jyubi.jpg")
img2 = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\2\goku black.jpeg")

if img1 is None or img2 is None:
    print("Error loading images")
    exit()

# Convert to grayscale
gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

# Create SIFT detector
sift = cv2.SIFT_create()

# Detect keypoints and descriptors
kp1, des1 = sift.detectAndCompute(gray1, None)
kp2, des2 = sift.detectAndCompute(gray2, None)

# Match features using BFMatcher
bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
matches = bf.knnMatch(des1, des2, k=2)

# Lowe's ratio test
good = []
for m, n in matches:
    if m.distance < 0.75 * n.distance:
        good.append(m)

if len(good) > 4:

    # Extract matched keypoints
    src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1,1,2)
    dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1,1,2)

    # Find Homography
    H, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)

    # Get size of final stitched image
    h1, w1 = img1.shape[:2]
    h2, w2 = img2.shape[:2]

    # Warp first image
    result = cv2.warpPerspective(img1, H, (w1 + w2, max(h1, h2)))

    # Place second image on canvas
    result[0:h2, 0:w2] = img2

    # Show result
    plt.figure(figsize=(10,5))
    plt.imshow(cv2.cvtColor(result, cv2.COLOR_BGR2RGB))
    plt.title("Stitched Image")
    plt.axis("off")
    plt.show()

    cv2.imwrite("stitched_output.jpg", result)

else:
    print("Not enough matches found")
