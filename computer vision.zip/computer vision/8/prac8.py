from PIL import Image
import numpy as np
import matplotlib.pyplot as plt

def shift_image(img, depth_img, shift_amount=10):
    img = img.convert("RGBA")
    
    # ✅ Resize depth image to match original image size
    depth_img = depth_img.resize(img.size)
    depth_img = depth_img.convert("L")

    data = np.array(img)
    depth_data = np.array(depth_img)

    deltas = ((depth_data / 255.0) * float(shift_amount)).astype(int)

    shifted_data = np.zeros_like(data)
    height, width, _ = data.shape

    for y in range(height):
        for x in range(width):
            dx = deltas[y, x]
            new_x = x + dx

            if 0 <= new_x < width:
                shifted_data[y, new_x] = data[y, x]

    shifted_image = Image.fromarray(shifted_data.astype(np.uint8))
    return shifted_image


# ✅ Your image paths
img = Image.open(r"C:\Users\pavan\Downloads\computer vision\8\cube.jpeg")

depth_img = Image.open(r"C:\Users\pavan\Downloads\computer vision\8\cube2.jpeg")

shifted_img = shift_image(img, depth_img)

# Display
fig, axs = plt.subplots(1, 2, figsize=(10, 5))

axs[0].imshow(img)
axs[0].set_title("Original Image")
axs[0].axis("off")

axs[1].imshow(shifted_img)
axs[1].set_title("Shifted Image")
axs[1].axis("off")

plt.show()
