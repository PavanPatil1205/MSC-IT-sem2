import cv2

img = cv2.imread(r"C:\Users\pavan\Downloads\computer vision\6\luffy.jpg")

if img is None:
    print("Image not loaded")
    exit()

# Convert to grayscale
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Apply color map (fake colorization)
colorized = cv2.applyColorMap(gray, cv2.COLORMAP_JET)

cv2.imshow("Original", img)
cv2.imshow("Colorized", colorized)

cv2.waitKey(0)
cv2.destroyAllWindows()
